

import pysal as ps
import geopandas as gdp
import os
'''Create new shp file from PySAL sample Data'''
os.getcwd()
os.chdir('/home/user/desktop/pysal_data') #set working directory to writable folder
os.getcwd() #check that it worked

output_shp = ('YOUR_STATE') # change to State abr

shp_path_nat = ps.examples.get_path('NAT.shp")
input = gdp.read_file(shp_path_nat)
#input.head() #if you need to check column names

selection = input.loc[input['STATE_FIPS'] == '36'] # Update to your State FIP
selection.to_file(output_shp)
#selection.plot() #plot selection to confirm shp file was made