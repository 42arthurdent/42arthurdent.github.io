# -*- coding: utf-8 -*-
#sudo apt-get update
#sudo apt-get install python3-pysal


##pysal is a module built to perform spatial statistical calculations, in contrast to packages like pyscopg and shapely that can perform deterministic spatial queries like where do points x fall within polygon y. 

#%%
import pysal as ps
import numpy as np
import geopandas as gpd
import matplotlib.pyplot as plt
from matplotlib import colors
#from pylab import figure, scatter, show


#PA
#test_shp = '/home/user/Desktop/pysal_data/pa/pa.shp'

test_shp = '/home/user/Desktop/pysal_data/tx/texas.shp'





#%%
#pysal can open and read spatial files and return some basic information

ps.examples.available() #list of the sample data in the packages
ps.examples.explain('us_income') #infomation about the data

us_shp_path = ps.examples.get_path('us48.shp') 
f = ps.open(us_shp_path)
all_polygons = f.read()
len(all_polygons)

all_polygons[0:5]
all_polygons[0].centroid
all_polygons[0].area
all_polygons[0].perimeter
#the header of the file, which contains most of the metadata about the file:
f.header


#pandas module will work if you have pandas installed but not loaded -it is a nicer way to display the data
ps.pdio
data_table = ps.pdio.read_files(us_shp_path)
data_table.head()

#%%

#we will start with some simple choropleths using the sample data

#pysal has built a built in visualization module "pysal.contrib.viz" that would only work in python 2.7 -ideal for simple diagrams for viewing prelim data

shp_path_nat = ps.examples.get_path('NAT.shp') #homicide rate per 100,000 people by county
#/usr/local/lib/python3.5/dist-packages/pysal/examples/nat/NAT.shp
dbf_path_nat = ps.examples.get_path('NAT.dbf')


values = np.array(ps.open(dbf_path_nat).by_col('HR90'))
hr90 = values
hr90q5 = ps.Quantiles(hr90, k=5)
hr90q5

'''
 Quantiles                
 
Lower            Upper              Count
=========================================
         x[i] <=  0.000               636
 0.000 < x[i] <=  3.120               598
 3.120 < x[i] <=  5.820               617
 5.820 < x[i] <= 10.328               617
10.328 < x[i] <= 71.378               617
'''

hr90q4 = ps.Quantiles(hr90, k=4)
hr90q4


hr90e5 = ps.Equal_Interval(hr90, k=5)
hr90e5

hr90fj5 = ps.Fisher_Jenks(hr90, k=5)
hr90fj5

hr90fj5.adcm # measure of fit: Absolute deviation around class means
hr90q5.adcm
hr90e5.adcm

hr90fj5.yb[0:10] # what bin each value is placed in

hr90fj5.bins # upper bounds of each bin


#using geopandas to display this information

#%%

nat = gpd.read_file(shp_path_nat)
#nat.plot(color = 'blue')
#nat.plot(column='HR90', scheme='QUANTILES')
nat.plot(column='HR90', scheme='QUANTILES', k=5, cmap='OrRd')
#nat.plot(color = 'blue',linewidth=0)


#%%
#well that took a while- lets work on a smaller set (TEXAS)

gpd.read_file(test_shp).plot(column = 'HR90', scheme='QUANTILES')
gpd.read_file(test_shp).plot(column = 'HR90', scheme='Equal_Interval')
gpd.read_file(test_shp).plot(column = 'HR90', scheme='Fisher_Jenks')
#import matplotlib.pyplot as plt


state=gpd.read_file(test_shp)
f, ax = plt.subplots(1, figsize=(9, 9))
state.plot(column='HR90', scheme='QUANTILES', k=5, cmap='OrRd', linewidth=0.1, ax=ax)
ax.set_axis_off()

#%%
#pysal works with Folium and the GeoJSON package to allow you to overlay your data on leaflet style basemaps 'Stamen Toner' etc
#from pysal.contrib.viz import folium_mapping as fm  --only loads in 2.7
#%%
#Spatial Weights -geographical similiarity
'''
#import pysal as ps
#import numpy as np
Queen Bishop and Rook Weights
A commonly-used type of weight is a queen contigutiy weight, which reflects adjacency
relationships as a binary indicator variable denoting whether or not a polygon shares an edge or a
vertex with another polygon
'''
qW = ps.queen_from_shapefile(test_shp)
dataframe = ps.pdio.read_files(test_shp)
qW[4]#neighbors & weights of the 5th observation 

self_and_neighbors = [4]
self_and_neighbors.extend(qW.neighbors[4])
print(self_and_neighbors)
dataframe.loc[self_and_neighbors]
#shows the neighbors of the choosen row
#creates a binary list (1 = neighbor)and only displays the non zero results
#qW.cardinalities[4]
#used to create weights to normalize values and compare neighboring values
#%%
#Distance based weights 
#PySAL reads in the data as simple x,y coordiates this can be corrected by 
radius = ps.cg.sphere.RADIUS_EARTH_MILES
radius
threshold = ps.min_threshold_dist_from_shapefile(test_shp,radius) # now in miles, maximum nearest neighbor distance between the n observations (centroids of counties)
threshold
#Other distance weights -
    #knn defined weights
    #Kernel Weights are continuous distance-based weights that use kernel densities to define the neighbor relationship.
plt.clf()
centroids = np.array([list(poly.centroid) for poly in dataframe.geometry])
plt.plot(centroids[:,0], centroids[:,1],'.')

#plt.ylim([25,37])
f, ax = plt.subplots(1,figsize=(9, 9))
state.plot(column='HR90', scheme='QUANTILES', k=5, cmap='OrRd', linewidth=0.1, ax=ax)
for k,neighs in qW.neighbors.items():#print(k,neighs)
    origin = centroids[k]
    for neigh in neighs:
        segment = centroids[[k,neigh]]
        plt.plot(segment[:,0], segment[:,1], '-')
plt.title('Queen Neighbor Graph')
ax.set_axis_off()
#%%
'''
Spatial Autocorrelation
The Queen (also rook and bishop) weights indicates if the two counties are neighbors
(i.e., geographically similar). What we also need is a measure of attribute similarity to pair up
with this concept of spatial similarity.
'''
#mapped as simple deciles
state = gpd.read_file(test_shp)
data = ps.pdio.read_files(test_shp)

hr10 = ps.Quantiles(data.HR90, k=10)
f, ax = plt.subplots(1, figsize=(9, 9))
state.assign(cl=hr10.yb).plot(column='cl', categorical=True, \
k=10, cmap='OrRd', linewidth=0.1, ax=ax, \
edgecolor='white', legend=True)
ax.set_axis_off()
plt.title("HR90 Deciles")


#%%
#mapped with spatial lag- weighted average of the attribute of the neighboring units

W = ps.queen_from_shapefile(test_shp)
W.transform = 'r'

HR90Lag = ps.lag_spatial(W, data.HR90)
HR90LagQ10 = ps.Quantiles(HR90Lag, k=10)

f, ax = plt.subplots(1, figsize=(9, 9))
state.assign(cl=HR90LagQ10.yb).plot(column='cl', categorical=True, \
    k=10, cmap='OrRd', linewidth=0.1, ax=ax, \
    edgecolor='white', legend=True)
ax.set_axis_off()
plt.title("HR90 Spatial Lag Deciles")
#%%
#Global Spatial Autocorrelation
HR90 = data.HR90
b,a = np.polyfit(HR90, HR90Lag, 1)
f, ax = plt.subplots(1, figsize=(9, 9))
plt.plot(HR90, HR90Lag, '.', color='firebrick')
# dashed vert at mean of the last year's PCI
plt.vlines(HR90.mean(), HR90Lag.min(), HR90Lag.max(), linestyle='--')
# dashed horizontal at mean of lagged PCI
plt.hlines(HR90Lag.mean(), HR90.min(), HR90.max(), linestyle='--')
# red line of best fit using global I as slope
plt.plot(HR90, a + b*HR90, 'r')
plt.title('Moran Scatterplot')
plt.ylabel('Spatial Lag of HR90')
plt.xlabel('HR90')

'''
I_HR90 = ps.Moran(data.HR90.values, W)
I_HR90.I, I_HR90.p_sim
(0.085976640313889768, 0.012999999999999999)
The global 'I' statistic is 0.859' for this data, and has a very small 'p' value.
very unlikely that this result was random
'''
#%%
#Local Autocorrelation Statistics computing the local Moran statistic for the same data shown above: 
#Local indicators of spatial association" (LISA)aka hot spots 
I_HR90 = ps.Moran(data.HR90.values, W)
LMo_HR90 = ps.Moran_Local(data.HR90.values, W)

LMo_HR90.Is[0:10], LMo_HR90.p_sim[0:10]

LMo_HR90 = ps.Moran_Local(data.HR90.values, W, permutations=9999)

#Creating a a Moran scatterplot with statistically significant LISA values highlighted.
Lag_HR90 = ps.lag_spatial(W, data.HR90.values)
HR90 = data.HR90.values
#finding the statistically significant LISAs
sigs = HR90[LMo_HR90.p_sim <= .001]
W_sigs = Lag_HR90[LMo_HR90.p_sim <= .001]
insigs = HR90[LMo_HR90.p_sim > .001]
W_insigs = Lag_HR90[LMo_HR90.p_sim > .001]

b,a = np.polyfit(HR90, Lag_HR90, 1)


#%%

plt.plot(sigs, W_sigs, '.', color='r')
plt.plot(insigs, W_insigs, '.k', alpha=.2)
# 
plt.vlines(HR90.mean(), Lag_HR90.min(), Lag_HR90.max(), linestyle='--')
# dashed horizontal at mean of lagged PCI
plt.hlines(Lag_HR90.mean(), HR90.min(), HR90.max(), linestyle='--')
# red line of best fit using global I as slope
plt.plot(HR90, a + b*HR90, 'r')
plt.title('Moran Scatterplot')
plt.ylabel('Spatial Lag of HR90')
plt.xlabel('HR90')
#%%
#LISA map of the data
sig = LMo_HR90.p_sim < 0.05
sig.sum()
hotspots = LMo_HR90.q==1 * sig
hotspots.sum()

coldspots = LMo_HR90.q==3 * sig
coldspots.sum()
data.HR90[hotspots]
#map of hotspots

hmap = colors.ListedColormap(['grey', 'red'])
f, ax = plt.subplots(1, figsize=(9, 9))
state.assign(cl=hotspots*1).plot(column='cl', categorical=True, \
k=2, cmap=hmap, linewidth=0.1, ax=ax, \
edgecolor='grey', legend=True)
ax.set_axis_off()
#%%
#coldspots

cmap = colors.ListedColormap(['grey', 'blue'])
f, ax = plt.subplots(1, figsize=(9, 9))
state.assign(cl=coldspots*1).plot(column='cl', categorical=True, \
k=2, cmap=cmap, linewidth=0.1, ax=ax, \
edgecolor='black', legend=True)
ax.set_axis_off()

#%%
#on the same plot

hcmap = colors.ListedColormap(['grey', 'red','blue'])
hotcold = hotspots*1 + coldspots*2
f, ax = plt.subplots(1, figsize=(9, 9))
state.assign(cl=hotcold).plot(column='cl', categorical=True, \
k=2, cmap=hcmap,linewidth=0.1, ax=ax, \
edgecolor='black', legend=True)
ax.set_axis_off()
plt.show()
